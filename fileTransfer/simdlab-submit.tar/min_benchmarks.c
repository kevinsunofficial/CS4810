#include <stdlib.h>
#include <limits.h>  /* for USHRT_MAX */

#include <immintrin.h>

#include "min.h"
/* reference implementation in C */
short min_C(long size, short * a) {
  short result = SHRT_MAX;
  for (int i = 0; i < size; ++i) {
    if (a[i] < result)
      result = a[i];
  }
  return result;
}

short min_AVX(long size, short * a) {
  __m256i partial = _mm256_set1_epi16(SHRT_MAX);
  for (int i=0; i<size; i+=16) {
    __m256i apart = _mm256_loadu_si256((__m256i*) &a[i]);
    partial = _mm256_min_epi16(partial, apart);
  }
  short extracted_partial[16];
  _mm256_storeu_si256((__m256i*) &extracted_partial, partial);
  short result = SHRT_MAX;
  for (int i = 0; i < 16; ++i) {
    if (extracted_partial[i] < result)
      result = extracted_partial[i];
  }
  return result;
}


/* This is the list of functions to test */
function_info functions[] = {
  {min_C, "C (local)"},
  // add entries here!
  {min_AVX, "AVX (C)"},
};
